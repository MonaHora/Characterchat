# CharacterChat APK

1. Create a new GitHub repo and upload everything in this folder (keep the .github folder).
2. Open the repo's Actions tab -> "Build APK" -> Run workflow (it also runs on every push to main).
3. When it finishes (about 5 min), open the run and download "CharacterChat-apk" from Artifacts. Unzip it to get app-debug.apk.
4. Copy it to your phone, allow "install unknown apps", and install.
5. In the app tap the gear, paste your Anthropic API key, and chat.

Your key stays on your device. Don't share the APK with others, since they would be using your key only if you pasted it, but keep the key private.
